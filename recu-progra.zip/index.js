let hamburguesas = [
    {'id': 1, 'nombre': 'Armonia', 'precio': 12000, 'descripcion': 'Doble medallón de carne, queso cheddar, queso roquefort, huevo frito y pan con queso gratinado.', 'img': './assets/hamburguesas/burga-1.jpg'},
    {'id': 2, 'nombre': 'Doble batalla', 'precio': 15000, 'descripcion': 'Doble medallón de carne, doble queso cheddar, doble beacon, cebolla caramelizada y pan con semillas de sésamo.', 'img': './assets/hamburguesas/burga-2.jpg'},
    {'id': 3, 'nombre': 'Clásica Law', 'precio': 9000, 'descripcion': 'Medallón de carne, queso cheddar, panceta, cebolla crispy, salsa barbacoa, tomate, lechuga y pan con semillas de sésamo.', 'img': './assets/hamburguesas/burga-3.jpg'},
    {'id': 4, 'nombre': 'Exotically', 'precio': 16500, 'descripcion': 'Medallón de carne, doble queso roquefort, rúcula, cebolla caramelizada, tomate, hongo portobello salteado y pan brioche con semillas.', 'img': './assets/hamburguesas/burga-4.jpg'},
    {'id': 5, 'nombre': 'La Bestia', 'precio': 19000, 'descripcion': 'Quíntuple medallón de carne, 5 capas de cheddar, panceta en cada piso, cheddar en cada piso, queso especial derretido y pan con queso gratinado.', 'img': './assets/hamburguesas/burga-5.jpg'},
    {'id': 6, 'nombre': 'Nuggy Chop', 'precio': 14500, 'descripcion': 'Doble medallón de carne, doble queso cheddar, doble panceta, cebolla caramelizada, Nuggets de muzzarella y pan con queso gratinado.', 'img': './assets/hamburguesas/burga-6.jpg'},
]

let bebidas = [
     {'id': 7, 'nombre': 'Agua sin gas (1L)', 'precio': 2000, 'descripcion': 'Botella 1 litro agua Villavicencio sin gas.', 'img': './assets/bebidas/agua-con-gas.png'},
    {'id': 8, 'nombre': 'Agua con gas (1L)', 'precio': 1500, 'descripcion': 'Botella 1 litro agua Saldan con gas.', 'img': './assets/bebidas/agua-sin-gas.png'},
    {'id': 9, 'nombre': 'Aquarius Manzana (3L)', 'precio': 5500, 'descripcion': 'Botella 3 litros agua saborizada Aquarius de manzana.', 'img': './assets/bebidas/aquarius-manzana.png'},
    {'id': 10, 'nombre': 'Aquarius Pomelo (3L)', 'precio': 5500, 'descripcion': 'Botella 3 litros agua saborizada Aquarius de pomelo.', 'img': './assets/bebidas/aquarius-pomelo.png'},
    {'id': 11, 'nombre': 'Aquarius Naranja (3L)', 'precio': 5500, 'descripcion': 'Botella 3 litros agua saborizada Aquarius de naranja.', 'img': './assets/bebidas/aquarius-naranja.png'},
    {'id': 12, 'nombre': 'Coca-Cola (1.5L)', 'precio': 4500, 'descripcion': 'Botella 1.5 litros de Coca-Cola.', 'img': './assets/bebidas/coca-cola.png'},
    {'id': 13, 'nombre': 'Sprite (1.5L)', 'precio': 4500, 'descripcion': 'Botella 1.5 litros de Sprite.', 'img': './assets/bebidas/sprite.png'},
]

let tragos = [
    {'id': 14, 'nombre': 'Campari', 'precio': 6000, 'descripcion': 'Vaso de Campari y jugo de naranja.', 'img': './assets/tragos/campari.png'},
    {'id': 15, 'nombre': 'Fernet', 'precio': 7000, 'descripcion': 'Vaso de Coca-Cola y Fernet.', 'img': './assets/tragos/fernet.png'},
    {'id': 16, 'nombre': 'Gancia', 'precio': 6000, 'descripcion': 'Vaso de Gancia y Sprite.', 'img': './assets/tragos/gancia.png'},
    {'id': 17, 'nombre': 'Ron Havana Club', 'precio': 9000, 'descripcion': 'Vaso de Ron y Coca-Cola.', 'img': './assets/tragos/ron.png'},
    {'id': 18, 'nombre': 'Daiquiri', 'precio': 7000, 'descripcion': 'Vaso de Daiquiri.', 'img': './assets/tragos/daiquiri.png'},
]

const estado = {
    hamburguesas: { buscar: "", ordenado: false },
    bebidas: { buscar: "", ordenado: false },
    tragos: { buscar: "", ordenado: false }
};

function mostrarProductos() {
    const listadoHamburguesas = document.getElementById("listado-hamburguesas");
    const listadoBebidas = document.getElementById("listado-bebidas");
    const listadoTragos = document.getElementById("listado-tragos");

    listadoHamburguesas.innerHTML = "";
    listadoBebidas.innerHTML = "";
    listadoTragos.innerHTML = "";

    function renderizarLista(array, contenedor, claseLi, configKey) {
        let items = [...array];
        const config = estado[configKey];

        if (config.buscar) {
            items = items.filter(item => 
                item.nombre.toLowerCase().includes(config.buscar.toLowerCase())
            );
        }

        if (config.ordenado) {
            items.sort((a, b) => a.precio - b.precio);
        }

        items.forEach(prod => {
            const li = document.createElement("li");
            li.className = claseLi;
            li.innerHTML = `
                <img class="img-producto" src="${prod.img}" alt="${prod.nombre}">
                <div>
                    <h3 class="nombre-producto">${prod.nombre}</h3>
                    <p class="precio-producto">$${prod.precio}</p>
                    <p class="descripcion-producto">${prod.descripcion}</p>
                </div>
                <button class="btn-agregar"> Agregar al carrito </button>
            `;
            
            const boton = li.querySelector(".btn-agregar");
            boton.addEventListener("click", () => agregarAlCarrito(prod));

            contenedor.appendChild(li);
        });
    }

    renderizarLista(hamburguesas, listadoHamburguesas, "li-hamburguesa", "hamburguesas");
    renderizarLista(bebidas, listadoBebidas, "li-bebida", "bebidas");
    renderizarLista(tragos, listadoTragos, "li-tragos", "tragos");
}

function obtenerCarrito() {
    return JSON.parse(localStorage.getItem("carrito")) || [];
}

function agregarAlCarrito(prod) {
    let carrito = obtenerCarrito();
    const itemExistente = carrito.find(item => item.id === prod.id);

    if (itemExistente) {
        itemExistente.cantidad++;
    } else {
        carrito.push({
            id: prod.id,
            nombre: prod.nombre,
            precio: prod.precio,
            cantidad: 1
        });
    }

    console.log("Carrito antes de subir a LocalStorage:", carrito);
    localStorage.setItem("carrito", JSON.stringify(carrito));
    alert(`Un/una: ${prod.nombre} fue agregado al carrito`);
}

document.getElementById("buscar-hamburguesa").addEventListener("input", (e) => {
    estado.hamburguesas.buscar = e.target.value;
    mostrarProductos();
});
document.getElementById("ordenar-hamburguesa").addEventListener("click", () => {
    estado.hamburguesas.ordenado = true;
    mostrarProductos();
});

document.getElementById("buscar-bebida").addEventListener("input", (e) => {
    estado.bebidas.buscar = e.target.value;
    mostrarProductos();
});
document.getElementById("ordenar-bebida").addEventListener("click", () => {
    estado.bebidas.ordenado = true;
    mostrarProductos();
});

document.getElementById("buscar-trago").addEventListener("input", (e) => {
    estado.tragos.buscar = e.target.value;
    mostrarProductos();
});
document.getElementById("ordenar-trago").addEventListener("click", () => {
    estado.tragos.ordenado = true;
    mostrarProductos();
});

mostrarProductos();





