function obtenerCarrito() {
    return JSON.parse(localStorage.getItem("carrito")) || [];
}

function guardarCarrito(carrito) {
    localStorage.setItem("carrito", JSON.stringify(carrito));
}

function cargarProductosCarrito() {
    const tabla = document.getElementById("tabla-carrito");
    const valorFinal = document.getElementById("valor-final");
    
    const cabecera = tabla.rows[0];
    tabla.innerHTML = "";
    tabla.appendChild(cabecera);

    const carrito = obtenerCarrito();
    let total = 0;

    carrito.forEach(prod => {
        total += prod.precio * prod.cantidad;

        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${prod.nombre}</td>
            <td>${prod.cantidad}</td>
            <td>$${prod.precio}</td>
            <td>
                <button class="btn-accion-mas" data-id="${prod.id}">+</button>
                <button class="btn-accion-menos" data-id="${prod.id}">-</button>
            </td>
        `;
        tabla.appendChild(fila);
    });

    valorFinal.textContent = `El valor final a pagar es de: $${total}`;

    document.querySelectorAll(".btn-accion-mas").forEach(btn => {
        btn.addEventListener("click", () => {
            const id = parseInt(btn.getAttribute("data-id"));
            modificarCantidad(id, 1);
        });
    });

    document.querySelectorAll(".btn-accion-menos").forEach(btn => {
        btn.addEventListener("click", () => {
            const id = parseInt(btn.getAttribute("data-id"));
            modificarCantidad(id, -1);
        });
    });
}

function modificarCantidad(id, cambio) {
    let carrito = obtenerCarrito();
    const prod = carrito.find(item => item.id === id);

    if (prod) {
        const nuevaCantidad = prod.cantidad + cambio;
        if (nuevaCantidad <= 0) {
            const confirmar = confirm("¿Desea eliminar este producto del carrito?");
            if (confirmar) {
                carrito = carrito.filter(item => item.id !== id);
            }
        } else {
            prod.cantidad = nuevaCantidad;
        }
    }

    guardarCarrito(carrito);
    cargarProductosCarrito();
}

function limpiarCarrito() {
    localStorage.removeItem("carrito");
    alert("Carrito limpiado correctamente");
    cargarProductosCarrito();
}

document.addEventListener("DOMContentLoaded", () => {
    cargarProductosCarrito();
    
    const btnLimpiar = document.querySelector(".btn-limpiar-carrito");
    if (btnLimpiar) {
        btnLimpiar.addEventListener("click", limpiarCarrito);
    }
});
